<?php

GFForms::include_addon_framework();

class GFBlueshiftAddOn extends GFAddOn {

	protected $_version = GF_BS_ADDON_VERSION;
	protected $_min_gravityforms_version = '1.9';
	protected $_slug = 'blueshift-addon';
	protected $_path = 'blueshift-addon/blueshift-addon.php';
	protected $_full_path = __FILE__;
	protected $_title = 'Gravity Forms Blueshift Add-on';
	protected $_short_title = 'Blueshift Add-on';

	private static $_instance = null;

	/**
	 * Get an instance of this class.
	 *
	 * @return GFBlueshiftAddOn
	 */
	public static function get_instance() {
		if ( self::$_instance == null ) {
			self::$_instance = new GFBlueshiftAddOn();
		}

		return self::$_instance;
	}

	/**
	 * Handles hooks and loading of language files.
	 */
	public function init() {
		parent::init();
		add_action( 'gform_after_submission', array( $this, 'after_submission' ), 5, 2 );
	}


	// # SCRIPTS & STYLES -----------------------------------------------------------------------------------------------

	/**
	 * Return the scripts which should be enqueued.
	 *
	 * @return array
	 */
	public function scripts() {
		$scripts = array();

		return array_merge( parent::scripts(), $scripts );
	}

	/**
	 * Return the stylesheets which should be enqueued.
	 *
	 * @return array
	 */
	public function styles() {
		$styles = array(
			array(
				'handle'  => 'bs_styles',
				'src'     => $this->get_base_url() . '/css/styles.css',
				'version' => $this->_version,
				'enqueue' => array(
					array( 'field_types' => array( 'poll' ) )
				)
			)
		);

		return array_merge( parent::styles(), $styles );
	}


	// # ADMIN FUNCTIONS -----------------------------------------------------------------------------------------------

	/**
	 * Configures the settings which should be rendered on the add-on settings tab.
	 *
	 * @return array
	 */
	public function plugin_settings_fields() {
		return array(
			array(
				'title'  => esc_html__( 'Blueshift Add-on Settings', 'blueshiftaddon' ),
				'fields' => array(
					array(
						'name'              => 'bs-apikey-auth',
						'label'				=> 'API Key',
						'type'              => 'text',
						'class'             => 'large',
					),

					array(
						'name'              => 'bs-eventkey-auth',
						'label'				=> 'Event API Key',
						'type'              => 'text',
						'class'             => 'large',
					)
				)
			)
		);
	}

	/**
	 * Configures the settings which should be rendered on the Form Settings > Blueshift Add-on tab.
	 *
	 * @return array
	 */
	public function form_settings_fields( $form ) {
		
		return array(
			array(
				'title'  => esc_html__( 'Blueshift Settings', 'blueshiftaddon' ),
				'fields' => array(
					array(
						'label' => esc_html__( 'Field Mapper', 'blueshiftaddon' ),
						'type'  => 'generic_map',
						'name'  => 'field_mapper',
						'key_field' => array(
							'title' => 'Blueshift Field Keys',
							'type'  => 'text',
							'allow_custom' => true,
							'choices' => array(
								array(
									'label' => 'First Name',
									'value' => 'firstname'
								),
								array(
									'label' => 'Last Name',
									'value' => 'lastname'
								),
								array(
									'label' => 'Birth Date',
									'value' => 'birth_dayofmonth'
								),
								array(
									'label' => 'Birth Month',
									'value' => 'birth_month'
								),
							)
						),
					),
				),
			),
		); 
	}


	/**
	 * Performing a custom action at the end of the form submission process.
	 *
	 * @param array $entry The entry currently being processed.
	 * @param array $form The form currently being processed.
	 */
	public function after_submission( $entry, $form ) {

		global $post;
		$postID = $post->ID;

		$postType = get_post_type( $postID );
		$current_url = get_permalink( $postID );

		$settings = $this->get_plugin_settings();
		$form_settings = $this->get_form_settings($form);

		$api_key = $settings['bs-apikey-auth'];

		if( $postType == 'resort' ) {

			$api_key = get_field( 'bs_api_key', $postID ) ? get_field( 'bs_api_key', $postID ) : $settings['bs-apikey-auth']; 

			error_log( 'API Key taken from Resort: ' . $api_key );
		} else {
			error_log( 'API Key taken from Settings: '  . $api_key);
		}


		$months = array(
			'January' => 1, 
			'February' => 2, 
			'March' => 3, 
			'April' => 4, 
			'May' => 5, 
			'June' => 6, 
			'July' => 7, 
			'August' => 8, 
			'September' => 9, 
			'October' => 10, 
			'November' => 11, 
			'December' => 12
		);


		$mappedFields = array();

		if( isset( $form_settings['field_mapper'] ) ) {

			error_log("Custom Fields: " . print_r($form_settings['field_mapper'], true));

			foreach($form_settings['field_mapper'] as $mapped_key) {

				$key = $mapped_key['key'];
	
				if( $mapped_key['custom_key'] !== '' ) {
					$key = $mapped_key['custom_key'];
				}
				
				$val_id = $mapped_key['value'];

	
				if($key == 'birth_month') {
					$mappedFields[$key] = ($months[rgar($entry, $val_id)]) ? $months[rgar($entry, $val_id)] : rgar($entry, $val_id);
				} else {

					if($val_id == 'gf_custom') {
						$mappedFields[$key] = $mapped_key['custom_value'];
					} else {
						$mappedFields[$key] = rgar($entry, $val_id);
					}

				}
			
			}

		}

		
		foreach($form['fields'] as $field) {
			if(get_class($field) === 'GF_Field_Email') {
				$emailID = $field['id'];
				$email = strtolower(rgar($entry, $emailID));

				$mappedFields['customer_id'] = $email;
				$mappedFields['email'] = $email;
			}
		}

		// default mapped fields
		$datetime = new DateTime('now', new DateTimeZone('America/New_York'));
		$mappedFields['websiteSignupDate'] = $datetime->format('Y-m-d\TH:i:sP');
		// $mappedFields['websiteSignupDate'] = date('c');
		$mappedFields['birth_year'] = '1900';
		$mappedFields['Source'] = 'WP:Gravity Form: ' . $form['title'];
		$mappedFields['URL'] = $current_url;
		$mappedFields['Type'] = ucfirst($postType);

		error_log('Blueshift Mapped Fields: ' . print_r($mappedFields, true));



		$data_json = json_encode($mappedFields);


		$url = "https://api.getblueshift.com/api/v1/customers";

		if(!empty($mappedFields['email'])) {
			$ch = curl_init($url);
			curl_setopt($ch, CURLOPT_POST, 1);
			curl_setopt($ch, CURLOPT_POSTFIELDS, $data_json);
			curl_setopt($ch, CURLOPT_HTTPHEADER, array(
				'Content-Type: application/json',
				'Authorization: Basic ' . base64_encode($api_key) // Include API key in the request headers
			));
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			$response = curl_exec($ch);

			if(curl_errno($ch)) {
				error_log('API Error: ' . curl_error($ch));
			} else {


				GFFormsModel::add_note(
					$entry['id'], // Entry ID
					0, // User ID, 0 means system
					'Blueshift', 
					'Successfully sent submission to Blueshift.' // Note content
				);
			}

			curl_close($ch);
		} else {
			echo "Email is required to update or create customer.";
		}
		
	}

}
