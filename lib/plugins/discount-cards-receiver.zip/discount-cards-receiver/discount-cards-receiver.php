<?php
/**
 * Plugin Name: Discount Cards Receiver
 * Description: Receives discount cards data from the VMB API and stores it in the database.
 * Version: 1.0
 * Author: Braudy Pedrosa
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

require_once plugin_dir_path(__FILE__) . 'shortcodes.php';

function enqueue_scripts() {
    wp_enqueue_script('discount-cards-receiver', plugin_dir_url(__FILE__) . 'src/js/custom.js', array('jquery'), '1.0', true);
    wp_enqueue_style('discount-cards-receiver', plugin_dir_url(__FILE__) . 'src/scss/styles.css', array(), '1.0', 'all');
}

add_action('wp_enqueue_scripts', 'enqueue_scripts');


