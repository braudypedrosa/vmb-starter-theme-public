<?php

function discount_cards_shortcode() {
    
    $response = wp_remote_get('https://www.vacationmyrtlebeach.com/wp-json/discount/v1/cards/?ver=1.0');

    if (is_wp_error($response)) {
        return '<div class="discount-cards-container"><p>Error fetching discount cards.</p></div>';
    }

    $output = '';

    $cards = json_decode($response['body'], true);

    // Initialize an empty array to store categories
    $categories = array();

    // Loop through the cards and collect categories
    foreach ($cards as $card) {
        if (isset($card['category'])) {
            $categories[] = $card['category'];
        }

        if(empty($card['image'])) {
            $card['image'] = 'https://www.crownreef.com/wp-content/uploads/sites/2/2022/11/default-placeholder-300x300-1.png';
        }

        $output .= '<div class="vmb-card-item" data-category="'.$card['category'].'">'.
                '<div class="vmb-card-img"><a target="blank" href="'.$card['website'].'"><img src="'.$card['image'].'" alt="'.$card['title'].'"/></a></div>'.
                '<div class="vmb-card-details">'.
                    '<h3 class="vmb-card-title"><a target="blank" href="'.$card['website'].'">'.$card['title'].'</a></h3>'. 
                    '<div class="vmb-card-meta"><a href="tel:'.$card['phone'].'">'.$card['phone'].'</a><span> | </span>'.$card['address'].'</div>'.
                    '<p class="vmb-card-description">'.$card['content'].'</p>'.
                    '<a target="blank" href="'.$card['website'].'">Partner Website</a>'.
                '</div>'.
            '</div>';
    }

    // Get only unique categories
    $unique_categories = array_unique($categories);
    sort($unique_categories);


    $count = 0;

    $filters = '';

    foreach ($unique_categories as $category){
        $filters .= '<li class="'.(($count == 0) ? "active" : "").'" data-slug="'.$category.'">'.$category.'</li>';
        $count++;
    }

    

    return '<ul class="card-filters"><span>View: </span><li data-slug="*">All</li> '.$filters.'</ul><div class="vmb-cards">'.$output.'</div>';
}


add_shortcode('discount_cards', 'discount_cards_shortcode');