if(jQuery('card-filters')) {

    jQuery('.card-filters li').click(function(){
        jQuery('.card-filters li').removeClass('active');
        
        jQuery(this).addClass('active');
        var slug = jQuery(this).data('slug');

        if(slug == '*') {
          jQuery('.vmb-card-item').each(function(){
            jQuery(this).fadeIn(800);
          });
        } else {
          jQuery('.vmb-card-item').filter(function(){
              if(jQuery(this).data('category') == slug) {
                jQuery(this).fadeIn(800);
              } else {
                jQuery(this).fadeOut(200);
              }
            });
        } 
    }); 

    setTimeout(function() {
      jQuery('.card-filters li.active').click();
    },500);
}