<?php


// The active theme now owns the minimal field helpers Mapbox needs, so this
// plugin no longer loads its bundled ACF copy.
if ( function_exists( 'acf' ) ) {
    add_filter('acf/settings/save_json', BUB_PLUGIN_NAME . '_json_save_point');
    add_filter('acf/settings/load_json', BUB_PLUGIN_NAME . '_json_load_point');
}

function bub_mapbox_json_save_point( $path ) {
    return plugin_dir_path( dirname( __FILE__ ) ) . '/acf-json';
}

function bub_mapbox_json_load_point( $paths ) {
    unset($paths[0]);
    $paths[] = plugin_dir_path( dirname( __FILE__ ) ) . '/acf-json';
    return $paths;
}
    
