<?php 

add_action('wp_insert_post', BUB_PLUGIN_NAME . '_geolocate_address', 10, 3);

function bub_mapbox_geolocate_address($post_id, $post, $update) {

    if ($post->post_status === 'trash' || $post->post_status === 'deleted') {
        return; // Exit the function if the post is being trashed or deleted
    }

    $address = bub_mapbox_get_meta_field('address', $post_id);
    $coordinates = bub_mapbox_get_meta_field('coordinates', $post_id);

    if($address) {
        error_log('Address found for post: ' . $post->post_title . '(ID: '.$post_id.')');

        if( empty($coordinates['latitude']) || empty($coordinates['longitude']) ) {
            error_log('Coordinate not found! Running geolocation!');

            $new_coordinates = bub_mapbox_get_lat_long_from_address($address);
            
            bub_mapbox_update_coordinates($post_id, $new_coordinates['lat'], $new_coordinates['lng']);

            error_log('Assigned new coordinates: ' . print_r($new_coordinates, true));
        }
    }
}
